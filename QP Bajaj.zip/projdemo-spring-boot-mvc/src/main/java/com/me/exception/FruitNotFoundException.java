package com.me.exception;

public class FruitNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1631823366296521859L;

	public FruitNotFoundException() {
	}

	public FruitNotFoundException(String message) {
		super(message);
	}
}