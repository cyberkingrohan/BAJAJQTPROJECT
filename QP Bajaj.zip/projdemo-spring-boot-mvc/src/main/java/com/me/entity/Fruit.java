package com.me.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity
public class Fruit {
	//Mark it as primary key & automatically generate primary key
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int fruitId;
	
	
	private String name;
	
	
	private float price;


	public Fruit() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getFruitId() {
		return fruitId;
	}


	public void setFruitId(int fruitId) {
		this.fruitId = fruitId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Fruit [fruitId=" + fruitId + ", name=" + name + ", price=" + price + "]";
	}


	public Fruit(int fruitId, String name, float price) {
		super();
		this.fruitId = fruitId;
		this.name = name;
		this.price = price;
	}

	
	

}