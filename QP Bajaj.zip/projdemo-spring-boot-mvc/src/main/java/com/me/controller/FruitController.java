package com.me.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.me.entity.Fruit;
import com.me.exception.FruitNotFoundException;
import com.me.service.FruitService;

//TODO: Mark class as a REST controller
@RestController
@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
public class FruitController {

	@Autowired
	private FruitService fruitService;
	
	@PostMapping(value = "/register", consumes={MediaType.APPLICATION_JSON_VALUE})
	public Fruit registerFruit(@RequestBody @Valid Fruit fruit) {
		System.out.println(fruit.toString());
		return fruitService.registerFruit(fruit);
	}
	
	@PutMapping(value = "/update",consumes={MediaType.APPLICATION_JSON_VALUE})
	public Fruit updateFruit(@RequestBody @Valid Fruit fruit) {
		return fruitService.updateFruit(fruit);
	}
	
	@DeleteMapping(value = "/delete/{id}")
	public Fruit deleteFruit(@PathVariable("id") int fruitId) throws FruitNotFoundException {
		return fruitService.deleteFruit(fruitId);
	}
	
	@GetMapping(value = "/get/{id}")
	public Fruit getFruit(@PathVariable("id") int fruitId) throws FruitNotFoundException{
		return fruitService.getFruit(fruitId);
	}
	
	@GetMapping(value = "/getAll")
	public List<Fruit> getFruits() {
		return fruitService.getFruits();
		}
}