package com.me.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.me.dao.FruitRepository;
import com.me.entity.Fruit;
import com.me.exception.FruitNotFoundException;

@Service
public class FruitServiceImpl implements FruitService {

	@Autowired
	private FruitRepository fruitRepo;
	
	@Override
	public Fruit registerFruit(Fruit fruit) {
		return fruitRepo.save(fruit);
	}

	@Override
	public Fruit updateFruit(Fruit fruit) {
		return fruitRepo.save(fruit);
	}

	@Override
	public Fruit deleteFruit(int fruitId)  throws FruitNotFoundException{
		Optional<Fruit> fruit = fruitRepo.findById(fruitId);
		Fruit frt = null;
		if(fruit.isPresent()) {
			fruitRepo.deleteById(fruitId);
			frt = fruit.get();
		}else {
			throw new FruitNotFoundException("Fruit not found");
		}
		return frt;
	}

	@Override
	public Fruit getFruit(int fruitId)  throws FruitNotFoundException{
		Optional<Fruit> fruit = fruitRepo.findById(fruitId);
		Fruit frt = null;
		if(fruit.isPresent()) {
			frt = fruit.get();
		}else {
			throw new FruitNotFoundException("Fruit not found");
		}
		return frt;
	}

	@Override
	public List<Fruit> getFruits() {
		return fruitRepo.findAll();
		
	}
}